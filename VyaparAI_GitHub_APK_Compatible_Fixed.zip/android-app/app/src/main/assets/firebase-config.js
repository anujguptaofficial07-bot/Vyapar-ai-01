// Vyapar AI Firebase Config
// Firebase Console > Project settings > General > Your apps > Web app config
// In placeholders ko apne Firebase project values se replace karo.
// Jab tak yeh config real nahi hota, app local login mode me chalega.
window.VYAPAR_FIREBASE_CONFIG = {
  apiKey: "PASTE_FIREBASE_API_KEY",
  authDomain: "your-project-id.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project-id.appspot.com",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID",
  appId: "PASTE_FIREBASE_APP_ID"
};
