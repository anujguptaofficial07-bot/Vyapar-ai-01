# Vyapar AI Login + Cloud Backup Setup

Subscription feature is not included in this build. Only login + cloud backup is integrated.

## What is integrated

- Email/password login UI
- Local profile login fallback
- Firebase Auth hooks
- Firestore cloud backup hooks
- Save Data to Cloud button
- Restore Data from Cloud button
- Firebase config placeholder file
- Firestore security rules

## Files changed

- `web/index.html`
- `web/firebase-config.js`
- `android-app/app/src/main/assets/index.html`
- `android-app/app/src/main/assets/firebase-config.js`
- `docs/firestore.rules`

## Firebase steps

1. Open Firebase Console.
2. Create project.
3. Enable Authentication > Sign-in method > Email/Password.
4. Create Firestore Database.
5. Add a Web app in Firebase project settings.
6. Copy Firebase config values.
7. Paste them in both files:
   - `web/firebase-config.js`
   - `android-app/app/src/main/assets/firebase-config.js`
8. Publish Firestore rules from `docs/firestore.rules`.

## Data safety

The app saves data locally first. After cloud login, user can tap:

- `Save Data to Cloud` to upload current app data.
- `Restore Data from Cloud` to recover data after phone change/app reinstall.

## Mobile number

Mobile number is saved as profile data only. OTP login is not added because SMS OTP can become paid.
